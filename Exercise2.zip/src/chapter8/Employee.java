package chapter8;

public class Employee{
	public String name;
	public String grade; 
	public Employee(String name) {
		this.name = name;
	}
}
